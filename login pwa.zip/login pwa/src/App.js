import React from 'react';
//import logo from './logo.svg';
import { BrowserRouter, Switch, Route } from 'react-router-dom'
import './App.css';
import Login from './Login/login';
//import login from './Login/login';
import Home from './Login/Home';
import NoMatch from './Login/404Page'


class App extends React.Component {
  state={
    isLog: false
  }


  handleLogin = (isLog) => this.setState({isLog})
render(){
  const {isLog} = this.state;
    return (
      <div>
        <BrowserRouter>
        <Switch>
          <Route exact path='/' render={() => !isLog ?<Login isLogin={this.handleLogin}/>:<Home/> }/>
          <Route path='*' component={NoMatch}/>
         </Switch>
        </BrowserRouter>
      </div>
    )
  }
}

export default App;
